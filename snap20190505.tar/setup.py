from setuptools import setup
setup(name='sigfig',
      packages=['sigfig']
      )
