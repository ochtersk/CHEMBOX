from flask import Flask

qbox = Flask(__name__)

from qbox import routes
